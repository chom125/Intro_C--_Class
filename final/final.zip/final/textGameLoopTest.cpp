#include "testHarness.h"
#include "textGameLoop.h"

TEST(textGameLoopInitTest, textGameLoop){
	std::string input;
	std::cout << "bloopity bleep" << std::endl;
	getline(std::cin, input);
	std::cout << input << std::endl;
};