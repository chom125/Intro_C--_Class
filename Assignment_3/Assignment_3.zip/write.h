//write.h
#include <string>
#pragma once

void write(std::ostream& os, int i);
void write(std::ostream& os, float f);
void write(std::ostream& os, std::string);
void empty(std::stringstream&);