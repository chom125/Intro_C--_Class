/* Assignment 1-2
Write a program that prompts the user to enter an int, a double, and a string on
the command line. Read the values into variables of the appropriate data type with
std::cin. Write the 3 values to std::cout. This program does not require the use
of CppUnitLite. */

#include <iostream>
#include <string>

using std::string;
using std::cout;
using std::cin;
using std::endl;

int main()
{
    int i;
    cout << "Enter an int: ";
    cin >> i;
    
    
    double d;
    cout << "\nEnter a double: ";
    cin >> d;
    
    
    string s;
    cout << "\nenter a string: ";
    cin >> s;
    
    cout << "\n\nThe int entered was: " << i << "\nThe double entered was : " << d
    << "\nThe string entered was: " << s << endl;
    
    return 0;
}

